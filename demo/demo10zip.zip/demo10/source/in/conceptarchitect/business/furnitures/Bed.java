package in.conceptarchitect.business.furnitures;

public class Bed{

    int getPrice(){return 20000;}
}