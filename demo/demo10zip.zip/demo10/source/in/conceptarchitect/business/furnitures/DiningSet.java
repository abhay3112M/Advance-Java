public class in.conceptarchitect.DiningSet {

    Chair [] chairs;
    Table table;
    
}
