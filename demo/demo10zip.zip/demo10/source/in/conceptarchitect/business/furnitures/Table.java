package in.conceptarchitect.business.furnitures;

public class Table {

    public int getPrice(){ return 10000;}
}
