package in.conceptarchitect.business.furnitures;

public class Chair{

    int getPrice(){return 2000;}
}