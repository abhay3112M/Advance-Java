package in.conceptarchitect.utils.data;

public class QuickSort {
    
}
