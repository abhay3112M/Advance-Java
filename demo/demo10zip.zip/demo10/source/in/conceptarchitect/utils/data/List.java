package in.conceptarchitect.utils.data;

public class List {
    
}
