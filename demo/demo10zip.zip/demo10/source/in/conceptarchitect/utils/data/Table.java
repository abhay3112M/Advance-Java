package in.conceptarchitect.utils.data;

public class Table {

    public int getRowCount(){return 0;}
    public int getColumnCount(){return 0;}
}
