package com.dataminers.utils.data;

public class BinarySearch{

}